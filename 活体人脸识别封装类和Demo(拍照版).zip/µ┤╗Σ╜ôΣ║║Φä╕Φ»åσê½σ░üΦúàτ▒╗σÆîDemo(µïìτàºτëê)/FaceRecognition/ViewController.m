//
//  ViewController.m
//  FaceRecognition
//  Created by 聚财通 on 16/3/1.
//  Copyright © 2016年 付正. All rights reserved.
//
#import "ViewController.h"
#import "FaceStreamDetectorViewController.h"
@interface ViewController ()<FaceDetectorDelegate,UIScrollViewDelegate>
@property (nonatomic,strong) UITextField * name;
@property (nonatomic,strong) UITextField * idCard;
@property (nonatomic,strong) UIScrollView * ScrollView;
@end

@implementation ViewController
-(UIScrollView *)ScrollView{
    if (_ScrollView == nil) {
        _ScrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height)];
        _ScrollView.contentMode =   UIViewContentModeScaleToFill;
        _ScrollView.delegate = self;
        _ScrollView.userInteractionEnabled = YES;
        _ScrollView.scrollEnabled = YES;
        _ScrollView.contentSize = CGSizeMake([UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height*1.5);
        _ScrollView.backgroundColor = [UIColor greenColor];
        if (@available(iOS 11.0, *)) {
        _ScrollView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentAutomatic;
        } else {
            self.automaticallyAdjustsScrollViewInsets = NO;
        }
    }
   return  _ScrollView;
}
-(void)sendFaceImage:(NSMutableArray *)arrimG{
    [arrimG enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        UIImageView *imageV = [[UIImageView alloc]initWithFrame:CGRectMake((idx%3)*([UIScreen mainScreen].bounds.size.width/3), 150 +[UIScreen mainScreen].bounds.size.width/3*(1+idx/3), [UIScreen mainScreen].bounds.size.width/3, [UIScreen mainScreen].bounds.size.width/3)];
        imageV.image = arrimG[idx];
        [self.ScrollView addSubview:imageV];
    }];
}

-(UITextField *)name{
    if (_name == nil) {
    _name = [[UITextField alloc]initWithFrame:CGRectMake(50,100,200,30)];
        _name.keyboardType =  UIKeyboardTypeDefault;
        _name.borderStyle = UITextBorderStyleLine;
        _name.placeholder = @"姓名";
    }
    return _name;
}
-(UITextField *)idCard{
    if (_idCard == nil) {
        _idCard = [[UITextField alloc]initWithFrame:CGRectMake(50,150,200,30)];
        _idCard.keyboardType = UIKeyboardTypePhonePad;
        _idCard.borderStyle = UITextBorderStyleLine;
        _idCard.placeholder = @"身份证号码";
    }
    return _idCard;
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    [self buttonWithTitle:@"活体检测" frame:CGRectMake(50, 50,200,30)action:@selector(pushToFaceStreamDetectorVC) AddView:self.ScrollView];
    self.name.text = @"王玄策";
    self.idCard.text = @"101010062409052138";
    [self.view addSubview:self.ScrollView];
    [self.ScrollView addSubview:self.name];
    [self.ScrollView addSubview:self.idCard];
}
-(void)pushToFaceStreamDetectorVC
{
    [self.ScrollView.subviews enumerateObjectsUsingBlock:^(__kindof UIView * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([obj isKindOfClass:[UIImageView class]]) {
            [obj removeFromSuperview];
         }
      }];
    FaceStreamDetectorViewController *faceVC = [[FaceStreamDetectorViewController alloc]init];
      faceVC.name = self.name.text.copy;
      faceVC.idCard =   self.idCard.text.copy;
      faceVC.faceDelegate = self;
    [self.navigationController pushViewController:faceVC animated:YES];
}
#pragma mark --- 创建button公共方法
/**使用示例:[self buttonWithTitle:@"点 击" frame:CGRectMake((self.view.frame.size.width - 150)/2, (self.view.frame.size.height - 40)/3, 150, 40) action:@selector(didClickButton) AddView:self.view];*/
-(UIButton *)buttonWithTitle:(NSString *)title frame:(CGRect)frame action:(SEL)action AddView:(id)view
{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    button.frame = frame;
    button.backgroundColor = [UIColor colorWithRed:0.601 green:0.596 blue:0.906 alpha:1.000];
    [button setTitle:title forState:UIControlStateNormal];
    [button addTarget:self action:action forControlEvents:UIControlEventTouchDown];
    [view addSubview:button];
    return button;
}

-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    
}
@end
