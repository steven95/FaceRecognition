//
//  ViewController.m
//  FaceRecognition
//
//  Created by 聚财通 on 16/3/1.
//  Copyright © 2016年 付正. All rights reserved.
//

#import "ViewController.h"
#import "FaceStreamDetectorViewController.h"
@interface ViewController ()<FaceDetectorDelegate>
@property (nonatomic,strong) UITextField * name;
@property (nonatomic,strong) UITextField * idCard;
@end

@implementation ViewController

-(UITextField *)name{
    if (_name == nil) {
        _name = [[UITextField alloc]initWithFrame:CGRectMake(100,100,150,30)];
    }
    return _name;
}
-(UITextField *)idCard{
    if (_idCard == nil) {
        _idCard = [[UITextField alloc]initWithFrame:CGRectMake(100,150,150,30)];
    }
    return _idCard;
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    [self buttonWithTitle:@"活体检测" frame:CGRectMake(100, 50, 150, 30) action:@selector(pushToFaceStreamDetectorVC) AddView:self.view];
    
}
-(void)pushToFaceStreamDetectorVC
{
    FaceStreamDetectorViewController *faceVC = [[FaceStreamDetectorViewController alloc]init];
    faceVC.faceDelegate = self;
    [self.navigationController pushViewController:faceVC animated:YES];
}
#pragma mark --- 创建button公共方法
/**使用示例:[self buttonWithTitle:@"点 击" frame:CGRectMake((self.view.frame.size.width - 150)/2, (self.view.frame.size.height - 40)/3, 150, 40) action:@selector(didClickButton) AddView:self.view];*/
-(UIButton *)buttonWithTitle:(NSString *)title frame:(CGRect)frame action:(SEL)action AddView:(id)view
{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    button.frame = frame;
    button.backgroundColor = [UIColor colorWithRed:0.601 green:0.596 blue:0.906 alpha:1.000];
    [button setTitle:title forState:UIControlStateNormal];
    [button addTarget:self action:action forControlEvents:UIControlEventTouchDown];
    [view addSubview:button];
    return button;
}
@end
