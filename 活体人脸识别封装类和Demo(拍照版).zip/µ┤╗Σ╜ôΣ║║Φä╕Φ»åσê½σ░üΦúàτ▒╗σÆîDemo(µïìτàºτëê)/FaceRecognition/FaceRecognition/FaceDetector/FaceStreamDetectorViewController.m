//
//  FaceStreamDetectorViewController.m
//  IFlyFaceDemo
//
//  Created by 付正 on 16/3/1.
//  Copyright (c) 2016年 fuzheng. All rights reserved.
//
#import <SVProgressHUD/SVProgressHUD.h>
#import <AFNetworking/AFNetworking.h>
#import "FaceStreamDetectorViewController.h"
#import <AVFoundation/AVFoundation.h>
#import <AssetsLibrary/AssetsLibrary.h>
#import <QuartzCore/QuartzCore.h>
#import "PermissionDetector.h"
#import "UIImage+Extensions.h"
#import "UIImage+compress.h"
#import "iflyMSC/IFlyFaceSDK.h"
#import "DemoPreDefine.h"
#import "CaptureManager.h"
#import "CanvasView.h"
#import "CalculatorTools.h"
#import "UIImage+Extensions.h"
#import "IFlyFaceImage.h"
#import "IFlyFaceResultKeys.h"

@interface FaceStreamDetectorViewController ()<CaptureManagerDelegate>
{
    CGFloat aroundnum;
    int numcount;
    UILabel *alignLabel;
    int number;//
    NSTimer *timer;
    UIImageView *imgView;//动画图片展示
    //拍照操作
    AVCaptureStillImageOutput *myStillImageOutput;
    UIView *backView;//照片背景
    UIImageView *imageView;//照片展示
    int takePhotoNumber;
    int takePhoto;
    BOOL isCrossBorder;//判断是否越界
    BOOL isJudgeMouth;//判断张嘴操作完成
    BOOL isShakeHead;//判断摇头操作完成
    BOOL isDownHead;//判断点头操作完成
    BOOL isReShakeHead;//判断连续摇头操作完成
    BOOL isReDownlowHead;//判断连续点头操作完成
    BOOL isAround; //判断前后摆动
    BOOL isCrossleft;//左旋
    BOOL isCrossright;//右旋
    //嘴角坐标
    int leftX;
    int rightX;
    int lowerY;
    int upperY;
    //判断张嘴嘴型的宽高（初始的和后来变化的）
    int mouthWidthF;
    int mouthHeightF;
    int mouthWidth;
    int mouthHeight;
    //摇头嘴中点的数据
    int bigNumber;
    int smallNumber;
    //鼻子上下中点的数据
    int nosetop;
    int nose_top;
    int nosebottom;
    int nose_bottom;
    //前后位置
    CGFloat foraround;
    //左右眼睛坐标
    int left_eye_left;
    int right_eye_right;
}
@property (nonatomic,strong) NSMutableArray * ImageArr;
@property (nonatomic,strong) NSMutableArray * arrImage;
@property (nonatomic,strong) NSUserDefaults * isKeyFunc;
@property (nonatomic,strong) NSMutableSet * setKeyFunc;
@property (nonatomic,strong) NSMutableArray * arrKeyFunc;
@property (nonatomic,strong) NSMutableArray * KeyFunc;
@property (nonatomic, retain ) UIView  *previewView;
@property (nonatomic, strong ) UILabel *textLabel;
@property (nonatomic, retain ) AVCaptureVideoPreviewLayer *previewLayer;
@property (nonatomic, retain ) CaptureManager             *captureManager;
@property (nonatomic, retain ) IFlyFaceDetector           *faceDetector;
@property (nonatomic, strong ) CanvasView                 *viewCanvas;
@property (nonatomic, strong ) UITapGestureRecognizer     *tapGesture;
@property (nonatomic,strong) UIImageView * faceimgV;
@end

@implementation FaceStreamDetectorViewController
@synthesize captureManager;

-(NSMutableArray *)ImageArr{
    if (_ImageArr == nil) {
        _ImageArr = [NSMutableArray array];
    }
    return  _ImageArr;
}
-(NSMutableArray *)arrImage{
    if (_arrImage == nil) {
        _arrImage = [NSMutableArray array];
    }
    return  _arrImage;
}
-(NSMutableArray *)arrKeyFunc{
    if (_arrKeyFunc == nil) {
        _arrKeyFunc = [NSMutableArray array];
    }
    return _arrKeyFunc;
}
-(NSUserDefaults *)isKeyFunc{
    if (_isKeyFunc == nil) {
        _isKeyFunc = [NSUserDefaults standardUserDefaults];
        [_isKeyFunc setBool:isJudgeMouth forKey:@"FaceOpenMouth"];
        [_isKeyFunc setBool:isReShakeHead forKey:@"ReFaceShakeHead"];
        [_isKeyFunc setBool:isReDownlowHead forKey:@"ReFacedownHead"];
        [_isKeyFunc setBool:isAround forKey:@"Faceround"];
        [_isKeyFunc setBool:isCrossleft forKey:@"Crossleft"];
        [_isKeyFunc setBool:isCrossright forKey:@"Crossright"];
        [_isKeyFunc synchronize];
    }
    return _isKeyFunc;
}
-(NSMutableArray *)KeyFunc{
    if (_KeyFunc == nil) {
        _KeyFunc = [NSMutableArray array];
        [_KeyFunc addObject:@"FaceOpenMouth"];
        [_KeyFunc addObject:@"ReFaceShakeHead"];
        [_KeyFunc addObject:@"ReFacedownHead"];
        [_KeyFunc addObject:@"Faceround"];
        [_KeyFunc addObject:@"Crossleft"];
        [_KeyFunc addObject:@"Crossright"];
    }
    return _KeyFunc;
}
-(NSMutableSet *)setKeyFunc{
    
    if (_setKeyFunc == nil) {
        _setKeyFunc = [NSMutableSet set];
    }
    return _setKeyFunc;
}
-(void)viewDidLoad
{
    [super viewDidLoad];
    NSDictionary *dictionary = [self.isKeyFunc dictionaryRepresentation];
    for(NSString *key in [dictionary allKeys]){
        [self.isKeyFunc removeObjectForKey:key];
        [self.isKeyFunc synchronize];
    }
    self.view.backgroundColor = [UIColor whiteColor];
    //创建界面
    [self makeUI];
    //创建摄像页面
    [self makeCamera];
    //创建数据
    [self makeNumber];
    [self.setKeyFunc removeAllObjects];
    for (int i = 0; i <3; i++) {
        [self.setKeyFunc addObject:self.KeyFunc[(arc4random() % 6)]];
        if (self.setKeyFunc.count != 3 && i == 2) {
            i--;
        }
        NSLog(@"self.setKeyFunc%@",self.setKeyFunc);
    }
    [self.setKeyFunc enumerateObjectsUsingBlock:^(id  _Nonnull obj, BOOL * _Nonnull stop) {
        [self.arrKeyFunc addObject:obj];
        NSLog(@"self.arrKeyFunc%@",self.arrKeyFunc);
    }];
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
   
    //停止摄像
    [self.previewLayer.session stopRunning];
    [self.captureManager removeObserver];
}

-(void)makeNumber
{
    takePhoto = 0;
    takePhotoNumber = 0;
    isCrossright = NO;
    isCrossleft = NO;
    isReShakeHead = NO;
    isReDownlowHead = NO;
    isJudgeMouth = NO;
    isAround = NO;
    //张嘴数据
    number = 0;
    mouthWidthF = 0;
    mouthHeightF = 0;
    mouthWidth = 0;
    mouthHeight = 0;
    //摇头数据
    bigNumber = 0;
    smallNumber = 0;
    //点头数据
    nosetop = 0;
    nose_top = 0;
    nose_bottom = 0;
    nosebottom = 0;
    //调用次数
    numcount = 0;
    //前后数据
    foraround = 0;
    left_eye_left = 0   ;
    right_eye_right = 0;
}

#pragma mark --- 创建UI界面
-(void)makeUI
{
    self.previewView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight*2/3)];
    [self.view addSubview:self.previewView];
    //提示框
    imgView = [[UIImageView alloc]initWithFrame:CGRectMake((ScreenWidth-ScreenHeight/6+10)/2, CGRectGetMaxY(self.previewView.frame)+10, ScreenHeight/6-10, ScreenHeight/6-10)];
//    [self.view addSubview:imgView];
    self.textLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(imgView.frame)+5, ScreenWidth, 30)];
    self.textLabel.textAlignment = NSTextAlignmentCenter;
    self.textLabel.text = @"请按提示做动作";
    self.textLabel.textColor = [UIColor whiteColor];
    [self.view addSubview:self.textLabel];
    //背景View
    backView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight-64)];
    backView.backgroundColor = [UIColor lightGrayColor];
    //图片放置View
    imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 10, ScreenWidth, ScreenWidth*4/3)];
    [backView addSubview:imageView];
    //button上传图片
//    [self buttonWithTitle:@"上传图片" frame:CGRectMake(ScreenWidth/2-150, CGRectGetMaxY(imageView.frame)+10, 100, 30) action:@selector(didClickUpPhoto) AddView:backView];
    
    //重拍图片按钮
//    [self buttonWithTitle:@"重拍" frame:CGRectMake(ScreenWidth/2+50, CGRectGetMaxY(imageView.frame)+10, 100, 30) action:@selector(didClickPhotoAgain) AddView:backView];
}

#pragma mark --- 创建相机
-(void)makeCamera
{
    self.title = @"活体检测";
    //adjust the UI for iOS 7
#if __IPHONE_OS_VERSION_MAX_ALLOWED >= 70000
    if ( IOS7_OR_LATER ){
        self.edgesForExtendedLayout = UIRectEdgeNone;
        self.extendedLayoutIncludesOpaqueBars = NO;
        self.modalPresentationCapturesStatusBarAppearance = NO;
        self.navigationController.navigationBar.translucent = NO;
    }
#endif
    
    self.view.backgroundColor=[UIColor blackColor];
    self.previewView.backgroundColor=[UIColor clearColor];
    
    //设置初始化打开识别
    self.faceDetector=[IFlyFaceDetector sharedInstance];
    [self.faceDetector setParameter:@"1" forKey:@"detect"];
    [self.faceDetector setParameter:@"1" forKey:@"align"];
    [self.faceDetector setParameter:@"1" forKey:@"attr"];
    
    //初始化 CaptureSessionManager
    self.captureManager=[[CaptureManager alloc] init];
    self.captureManager.delegate=self;
    
    self.previewLayer=self.captureManager.previewLayer;
    
    self.captureManager.previewLayer.frame= self.previewView.frame;
    self.captureManager.previewLayer.position=self.previewView.center;
    self.captureManager.previewLayer.videoGravity=AVLayerVideoGravityResizeAspectFill;
    [self.previewView.layer addSublayer:self.captureManager.previewLayer];
    
    self.viewCanvas = [[CanvasView alloc] initWithFrame:self.captureManager.previewLayer.frame] ;
    self.faceimgV = [[UIImageView alloc]initWithFrame:self.captureManager.previewLayer.frame];
    [self.faceimgV setImage:[UIImage imageNamed:@"人物头像蒙版"]];
    [self.previewView addSubview:self.faceimgV] ;
    [self.faceimgV addSubview:self.viewCanvas] ;
self.viewCanvas.center=self.captureManager.previewLayer.position;
    self.viewCanvas.backgroundColor = [UIColor clearColor];
    NSString *str = [NSString stringWithFormat:@"{{%f, %f}, {220, 240}}",(ScreenWidth-220)/2,(ScreenWidth-240)/2+15];
    NSMutableDictionary *dic = [[NSMutableDictionary alloc]init];
    [dic setObject:str forKey:@"RECT_KEY"];
    [dic setObject:@"1" forKey:@"RECT_ORI"];
    NSMutableArray *arr = [[NSMutableArray alloc]init];
    [arr addObject:dic];
    self.viewCanvas.arrFixed = arr;
    self.viewCanvas.hidden = NO;
    
    //建立 AVCaptureStillImageOutput
    myStillImageOutput = [[AVCaptureStillImageOutput alloc] init];
    NSDictionary *myOutputSettings = [[NSDictionary alloc] initWithObjectsAndKeys:AVVideoCodecJPEG,AVVideoCodecKey,nil];
    [myStillImageOutput setOutputSettings:myOutputSettings];
    [self.captureManager.session addOutput:myStillImageOutput];
    
    //开始摄像
    [self.captureManager setup];
    [self.captureManager addObserver];
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
    [super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
    [self.captureManager observeValueForKeyPath:keyPath ofObject:object change:change context:context];
}
//代理之后开启识别优先级2
#pragma mark - 开启识别
- (void) showFaceLandmarksAndFaceRectWithPersonsArray:(NSMutableArray *)arrPersons
{
    if (self.viewCanvas.hidden) {
        self.viewCanvas.hidden = NO;
    }
    
    self.viewCanvas.arrPersons = arrPersons;
    [self.viewCanvas setNeedsDisplay] ;
}

#pragma mark --- 关闭识别
- (void) hideFace
{
    if (!self.viewCanvas.hidden) {
        self.viewCanvas.hidden = YES ;
    }
}
//代理之后画识别框优先级2
#pragma mark --- 脸部框识别
-(NSString*)praseDetect:(NSDictionary* )positionDic OrignImage:(IFlyFaceImage*)faceImg
{
    if(!positionDic){
        return nil;
    }
    
    // 判断摄像头方向
    BOOL isFrontCamera=self.captureManager.videoDeviceInput.device.position==AVCaptureDevicePositionFront;
    
    // scale coordinates so they fit in the preview box, which may be scaled
    CGFloat widthScaleBy = self.previewLayer.frame.size.width / faceImg.height;
    CGFloat heightScaleBy = self.previewLayer.frame.size.height / faceImg.width;
    
    CGFloat bottom =[[positionDic objectForKey:KCIFlyFaceResultBottom] floatValue];
    CGFloat top=[[positionDic objectForKey:KCIFlyFaceResultTop] floatValue];
    CGFloat left=[[positionDic objectForKey:KCIFlyFaceResultLeft] floatValue];
    CGFloat right=[[positionDic objectForKey:KCIFlyFaceResultRight] floatValue];
    
    float cx = (left+right)/2;
    float cy = (top + bottom)/2;
    float w = right - left;
    float h = bottom - top;
    
    float ncx = cy ;
    float ncy = cx ;
    
    CGRect rectFace = CGRectMake(ncx-w/2 ,ncy-w/2 , w, h);
    
    if(!isFrontCamera){
        rectFace=rSwap(rectFace);
        rectFace=rRotate90(rectFace, faceImg.height, faceImg.width);
    }
    
    //判断位置
    BOOL isNotLocation = [self identifyYourFaceLeft:left right:right top:top bottom:bottom];
    
    if (isNotLocation==YES) {
        return nil;
    }
    
    NSLog(@"left=%f right=%f top=%f bottom=%f",left,right,top,bottom);
    
    isCrossBorder = NO;
    
    rectFace=rScale(rectFace, widthScaleBy, heightScaleBy);
    
    return NSStringFromCGRect(rectFace);
}
//代理之后其次调用优先级2
#pragma mark --- 脸部部位识别
-(NSMutableArray*)praseAlign:(NSDictionary* )landmarkDic OrignImage:(IFlyFaceImage*)faceImg
{
    if(!landmarkDic){
        return nil;
    }
    // 判断摄像头方向
    BOOL isFrontCamera= self.captureManager.videoDeviceInput.device.position== AVCaptureDevicePositionFront;
    // scale coordinates so they fit in the preview box, which may be scaled
    CGFloat widthScaleBy = self.previewLayer.frame.size.width / faceImg.height;
    CGFloat heightScaleBy = self.previewLayer.frame.size.height / faceImg.width;
    NSMutableArray *arrStrPoints = [NSMutableArray array];
     NSLog(@"jusive-arrStrPoints%@",arrStrPoints);
    NSEnumerator* keys=[landmarkDic keyEnumerator];
    NSLog(@"jusive-keys%@",keys);
    for(id key in keys){
        id attr=[landmarkDic objectForKey:key];
        if(attr && [attr isKindOfClass:[NSDictionary class]]){
            id attr=[landmarkDic objectForKey:key];
            CGFloat x=[[attr objectForKey:KCIFlyFaceResultPointX] floatValue];
            CGFloat y=[[attr objectForKey:KCIFlyFaceResultPointY] floatValue];
            CGPoint p = CGPointMake(y,x);
            if(!isFrontCamera){
                p=pSwap(p);
                p=pRotate90(p, faceImg.height, faceImg.width);
            }
            //判断是否越界
            if (isCrossBorder == YES) {
                [self delateNumber];//清数据
                return nil;
            }
            dispatch_async(dispatch_get_global_queue(0, 0 ), ^{
                 [self acrefucnOpen:key p:p];
            });
           
            p=pScale(p, widthScaleBy, heightScaleBy);
            [arrStrPoints addObject:NSStringFromCGPoint(p)];
        }
    }
    return arrStrPoints;
}
//代理之后首先调用优先级1
#pragma mark --- 脸部识别
-(void)praseTrackResult:(NSString*)result OrignImage:(IFlyFaceImage*)faceImg
{
    if(!result){
        return;
    }
    @try {
        NSError* error;
        NSData* resultData=[result dataUsingEncoding:NSUTF8StringEncoding];
        NSDictionary* faceDic=[NSJSONSerialization JSONObjectWithData:resultData options:NSJSONReadingMutableContainers error:&error];
        resultData=nil;
        if(!faceDic){
            return;
        }
        NSString* faceRet=[faceDic objectForKey:KCIFlyFaceResultRet];
        NSArray* faceArray=[faceDic objectForKey:KCIFlyFaceResultFace];
        faceDic=nil;
        int ret=0;
        if(faceRet){
            ret=[faceRet intValue];
        }
        //没有检测到人脸或发生错误
        if (ret || !faceArray || [faceArray count]<1) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [self hideFace];
            }) ;
            return;
        }
        //检测到人脸
        NSMutableArray *arrPersons = [NSMutableArray array] ;
        for(id faceInArr in faceArray){
            
            if(faceInArr && [faceInArr isKindOfClass:[NSDictionary class]]){
                
                NSDictionary* positionDic=[faceInArr objectForKey:KCIFlyFaceResultPosition];
                NSString* rectString=[self praseDetect:positionDic OrignImage: faceImg];
                positionDic=nil;
                
                NSDictionary* landmarkDic=[faceInArr objectForKey:KCIFlyFaceResultLandmark];
                NSMutableArray* strPoints=[self praseAlign:landmarkDic OrignImage:faceImg];
                landmarkDic=nil;
                NSMutableDictionary *dicPerson = [NSMutableDictionary dictionary] ;
                if(rectString){
                    [dicPerson setObject:rectString forKey:RECT_KEY];
                }
                if(strPoints){
                    [dicPerson setObject:strPoints forKey:POINTS_KEY];
                }
                strPoints=nil;
                [dicPerson setObject:@"0" forKey:RECT_ORI];
                [arrPersons addObject:dicPerson] ;
                dicPerson=nil;
                dispatch_async(dispatch_get_main_queue(), ^{
                    [self showFaceLandmarksAndFaceRectWithPersonsArray:arrPersons];
                });
            }
        }
        faceArray=nil;
    }
    @catch (NSException *exception) {
        NSLog(@"prase exception:%@",exception.name);
    }
    @finally {
    }
}
//代理入口 ----->实时调用
#pragma mark - CaptureManagerDelegate
-(void)onOutputFaceImage:(IFlyFaceImage*)faceImg
{
    NSString* strResult=[self.faceDetector trackFrame:faceImg.data withWidth:faceImg.width height:faceImg.height direction:(int)faceImg.direction];
    NSLog(@"result:%@",strResult);
    
    //此处清理图片数据，以防止因为不必要的图片数据的反复传递造成的内存卷积占用。
    faceImg.data=nil;
    
    NSMethodSignature *sig = [self methodSignatureForSelector:@selector(praseTrackResult:OrignImage:)];
    if (!sig) return;
    NSInvocation* invocation = [NSInvocation invocationWithMethodSignature:sig];
    [invocation setTarget:self];
    [invocation setSelector:@selector(praseTrackResult:OrignImage:)];
    [invocation setArgument:&strResult atIndex:2];
    [invocation setArgument:&faceImg atIndex:3];
    [invocation retainArguments];
    [invocation performSelectorOnMainThread:@selector(invoke) withObject:nil  waitUntilDone:NO];
    faceImg=nil;
}
//代理之后计算数据优先级3
#pragma mark --- 判断位置
-(BOOL)identifyYourFaceLeft:(CGFloat)left right:(CGFloat)right top:(CGFloat)top bottom:(CGFloat)bottom
{
    aroundnum = bottom - top;
    NSLog(@"aroundnum%f",aroundnum);
    //判断位置
    if (right - left < 230 || bottom - top < 250) {
        self.textLabel.text = @"太远了...";
        NSLog(@"1太远了...");
        [self delateNumber];//清数据
        isCrossBorder = YES;
        return YES;
    }else if (right - left > 320 || bottom - top > 320) {
        self.textLabel.text = @"太近了...";
        NSLog(@"2太近了...");
        [self delateNumber];//清数据
        isCrossBorder = YES;
        return YES;
    }else{
        if (self.viewCanvas.hidden) {
            self.viewCanvas.hidden = NO;
        }
    }
    return NO;
}
-(void)acrefucnnum:(int)num key:(NSString *)key p:(CGPoint )p{
    
    if ([self.arrKeyFunc[num] isEqualToString:@"FaceOpenMouth"]) {
        [self identifyYourFaceOpenMouth:key p:p];
        dispatch_async(dispatch_get_main_queue(), ^{
              self.textLabel.text = @"请重复张嘴动作";
        });
        NSLog(@"111111111");
    }
    if ([self.arrKeyFunc[num] isEqualToString:@"ReFaceShakeHead"]) {
        [self identifyYourReFaceShakeHead:key p:p];
        dispatch_async(dispatch_get_main_queue(), ^{
            self.textLabel.text = @"请持续摇头";
        });
        NSLog(@"222222222");
    }
    if ([self.arrKeyFunc[num] isEqualToString:@"ReFacedownHead"]) {
        [self identifyYourReFacedownHead:key p:p];
        dispatch_async(dispatch_get_main_queue(), ^{
              self.textLabel.text = @"请持续点头";
        });
        NSLog(@"3333333333");
    }
    if ([self.arrKeyFunc[num] isEqualToString:@"Crossleft"]) {
        [self identifyYourFaceCrossleft:key p:p];
        dispatch_async(dispatch_get_main_queue(), ^{
            self.textLabel.text = @"请来回向左旋转手机";
        });
        NSLog(@"444444444444");
    }
    if ([self.arrKeyFunc[num]  isEqualToString:@"Crossright"]) {
        [self identifyYourFaceCrossright:key p:p];
        dispatch_async(dispatch_get_main_queue(), ^{
            self.textLabel.text = @"请来回向右旋转手机";
        });
        NSLog(@"55555555555");
    }
    if ([self.arrKeyFunc[num] isEqualToString:@"Faceround"]) {
        [self identifyYourFaceAround:aroundnum];
        dispatch_async(dispatch_get_main_queue(), ^{
              self.textLabel.text = @"请前后移动手机";
        });
        NSLog(@"666666666");
    }
}
#pragma mark --- 预备拍照
-(void)acrefucnOpen:(NSString *)key p:(CGPoint )p{
      if (self.arrKeyFunc.count != 0) {
        if ([self.isKeyFunc objectForKey:self.arrKeyFunc[0]] == 0 && self.arrKeyFunc.count >=1) {
            [self acrefucnnum:0 key:key p:p];
                takePhoto ++;
            if (takePhoto == 1200) {
                [self didClickTakePhoto:NO];
//                [self doUploadPhoto:self.arrImage.lastObject];
                takePhoto = 0;
            }
        }else if ([self.isKeyFunc objectForKey:self.arrKeyFunc[1]] == 0  && self.arrKeyFunc.count >=2){
            [self acrefucnnum:1 key:key p:p];
            takePhoto ++;
            if (takePhoto == 1200) {
                [self didClickTakePhoto:NO];
//                [self doUploadPhoto:self.arrImage.lastObject];
                takePhoto = 0;
            }
        }else if ([self.isKeyFunc objectForKey:self.arrKeyFunc[2]] == 0 && self.arrKeyFunc.count == 3){
              [self acrefucnnum:2 key:key p:p];
            takePhoto ++;
            if (takePhoto == 1200) {
                [self didClickTakePhoto:NO];
//                [self doUploadPhoto:self.arrImage.lastObject];
                takePhoto = 0;
            }
        }else{
              takePhotoNumber ++;
            if (1200 > takePhotoNumber && takePhotoNumber > 0){
            dispatch_async(dispatch_get_main_queue(), ^{
                 self.textLabel.text = @"请注视屏幕";
            });}
             else if (1800 > takePhotoNumber && takePhotoNumber > 1200){
                 dispatch_async(dispatch_get_main_queue(), ^{
                     self.textLabel.text = @"3s后拍照";
                 });
                
            }else  if (2400> takePhotoNumber && takePhotoNumber > 1800){
                dispatch_async(dispatch_get_main_queue(), ^{
                     self.textLabel.text = @"2s后拍照";
                });
               
            }else  if (3000 >takePhotoNumber && takePhotoNumber > 2400){
                dispatch_async(dispatch_get_main_queue(), ^{
                     self.textLabel.text = @"1s后拍照";
                });
            }
               if (takePhotoNumber == 3000) {
                   [self didClickTakePhoto:YES];
               }
           
        }
    }
}

//代理之后判断数据先级3
#pragma mark --- 判断是否左旋
-(void)identifyYourFaceCrossleft:(NSString *)key p:(CGPoint )p{
    NSLog(@"identifyYourFaceCrossright%d",numcount);
    if ([key isEqualToString:@"left_eye_left_corner"]) {
        if (left_eye_left == 0) {
            left_eye_left = p.y;
        }else if (p.y - left_eye_left >= 250){
            left_eye_left = p.y;
            numcount ++;
        }else if (left_eye_left - p.y >= 250){
            left_eye_left = p.y;
            numcount ++;
        }
        
    }
    if ([key isEqualToString:@"right_eye_right_corner"]) {
        if (right_eye_right == 0) {
            right_eye_right = p.x;
        }else if (p.x - right_eye_right >= 150){
            right_eye_right = p.x;
            numcount ++;
        }else if (right_eye_right - p.x >= 150){
            right_eye_right = p.x;
            numcount ++;
        }
    }
    if (numcount >= 4) {
        [self delateNumber];
        isCrossleft = YES;
        numcount = 0;
        [self.isKeyFunc setBool:isCrossleft forKey:@"Crossleft"];
    }
}
//代理之后判断数据优先级3
#pragma mark --- 判断是否右旋
-(void)identifyYourFaceCrossright:(NSString *)key p:(CGPoint )p{
    NSLog(@"identifyYourFaceCrossleft%d",numcount);
    NSLog(@"p.x - left_eye_left%f",left_eye_left - p.x);
    if ([key isEqualToString:@"left_eye_left_corner"]) {
        if (left_eye_left == 0) {
            left_eye_left = p.x;
        }else if (p.x- left_eye_left >= 150){
            NSLog(@"1left_eye_left_corner");
            left_eye_left = p.x;
            numcount ++;
        }else if (left_eye_left -p.x >= 150){
             NSLog(@"2left_eye_left_corner");
            left_eye_left = p.x;
            numcount ++;
        }
    }
    if ([key isEqualToString:@"right_eye_right_corner"]) {
        if (right_eye_right == 0) {
            right_eye_right = p.y;
        }else if (p.y - right_eye_right >= 250){
            right_eye_right = p.y;
            numcount ++;
        }else if (right_eye_right - p.y >= 250){
            right_eye_right = p.y;
            numcount ++;
        }
    }
    if (numcount >= 4) {
        [self delateNumber];
        isCrossright = YES;
        numcount = 0;
        [self.isKeyFunc setBool:isCrossright forKey:@"Crossright"];
    }
}
//代理之后判断数据优先级3
#pragma mark --- 判断是否前后移动
-(void)identifyYourFaceAround:(CGFloat)around {
    if (foraround == 0) {
        foraround = around;
        
    }else if (around - foraround > 30){
        foraround = around;
        numcount ++;
    }else if (foraround - around > 30){
        foraround = around ;
        numcount ++;
    }
    if (numcount >= 4) {
        [self delateNumber];
        isAround = YES;
        numcount = 0;
    [self.isKeyFunc setBool:isAround forKey:@"Faceround"];
        [self.isKeyFunc synchronize];
    }
}
//代理之后判断数据优先级3
#pragma mark --- 判断是否张嘴
-(void)identifyYourFaceOpenMouth:(NSString *)key p:(CGPoint )p
{
    NSLog(@"+++++++++++++张嘴");
    if ([key isEqualToString:@"mouth_upper_lip_top"]) {
        upperY = p.y;
    }
    if ([key isEqualToString:@"mouth_lower_lip_bottom"]) {
        lowerY = p.y;
    }
    if ([key isEqualToString:@"mouth_left_corner"]) {
        leftX = p.x;
    }
    if ([key isEqualToString:@"mouth_right_corner"]) {
        rightX = p.x;
    }
    if (rightX && leftX && upperY && lowerY && isJudgeMouth != YES) {
        
        number ++;
        if (number == 1 || number == 300 || number == 600 || number ==900) {
            //延时操作
//            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            
            mouthWidthF = rightX - leftX < 0 ? abs(rightX - leftX) : rightX - leftX;
            mouthHeightF = lowerY - upperY < 0 ? abs(lowerY - upperY) : lowerY - upperY;
            NSLog(@"%d,%d",mouthWidthF,mouthHeightF);
//            });
        }//else if (number > 1200) {
//            [self delateNumber];//时间过长时重新清除数据
//            [self tomAnimationWithName:@"openMouth" count:2];
        //}
        
        mouthWidth = rightX - leftX < 0 ? abs(rightX - leftX) : rightX - leftX;
        mouthHeight = lowerY - upperY < 0 ? abs(lowerY - upperY) : lowerY - upperY;
        NSLog(@"%d,%d",mouthWidth,mouthHeight);
        NSLog(@"张嘴前：width=%d，height=%d",mouthWidthF - mouthWidth,mouthHeight - mouthHeightF);
        if (mouthWidth && mouthWidthF) {
            //张嘴验证完毕
            if (mouthHeight - mouthHeightF >= 20 && mouthWidthF - mouthWidth >= 15) {
                isJudgeMouth = YES;
                [self.isKeyFunc setBool:isJudgeMouth forKey:@"FaceOpenMouth"];
              [self.isKeyFunc synchronize];
//                imgView.animationImages = nil;
            }
        }
    }
}
//代理之后判断数据优先级3
#pragma mark --- 判断是否持续摇头
-(void)identifyYourReFaceShakeHead:(NSString *)key p:(CGPoint )p
{
//      NSLog(@"+++++++++++++持续摇头");
    [self FaceShakeHead:key p:p];
    //摇头验证完毕
    if (bigNumber - smallNumber > 60) {
        [self delateNumber];//清数据
        [self FaceShakeHead:key p:p];
            numcount ++;
        if (numcount >= 4) {
            isReShakeHead = YES;
            [self.isKeyFunc setBool:isReShakeHead forKey:@"ReFaceShakeHead"];
             [self.isKeyFunc synchronize];
            [self delateNumber];
            numcount = 0;
//            NSLog(@"+++++++++++++isReShakeHead摇头");
        }
    }
}

-(void)FaceShakeHead:(NSString *)key p:(CGPoint )p{
    if ([key isEqualToString:@"mouth_middle"]) {
        if (bigNumber == 0 ) {
            bigNumber = p.x;
            smallNumber = p.x;
        }else if (p.x > bigNumber) {
            bigNumber = p.x;
        }else if (p.x < smallNumber) {
            smallNumber = p.x;
        }
    }
}

//代理之后判断数据优先级3
#pragma mark --- 判断是否持续点头
-(void)identifyYourReFacedownHead:(NSString *)key p:(CGPoint )p
{
        [self ReFacedownHead:key p:p];
    if (nosetop -nose_top >40 && nosebottom - nose_bottom >40) {
            numcount ++;
        [self delateNumber];
        [self ReFacedownHead:key p:p];
        if (numcount >= 3) {
            isReDownlowHead = YES;
            [self.isKeyFunc setBool:isReDownlowHead forKey:@"ReFacedownHead"];
             [self.isKeyFunc synchronize];
            [self delateNumber];
            numcount = 0;
   NSLog(@"+++++++++++++isReDownlowHead点头");
        }
    }
}
-(void)ReFacedownHead:(NSString *)key p:(CGPoint )p{
    if ([key isEqualToString:@"nose_bottom"]) {
        if (nosebottom == 0 ) {
            nosebottom = p.y;
            nose_bottom = p.y;
             NSLog(@"1nosebottom%d",nosebottom);
             NSLog(@"1nose_bottom%d",nose_bottom);
        }else if (p.y > nosebottom) {
            nosebottom = p.y;
             NSLog(@"2nosebottom%d",nosebottom);
        }
        if (nosebottom - nose_bottom > 60) {
            nosebottom = nose_bottom;
            nose_bottom = p.y;
             NSLog(@"3nosebottom%d",nosebottom);
        }
    }
    if ([key isEqualToString:@"nose_top"]) {
        if (nosetop == 0) {
            nosetop = p.y;
            nose_top = p.y;
             NSLog(@"1nosetop%d",nosetop);
             NSLog(@"1nose_top%d",nose_top);
        }else if (p.y > nosetop){
            nosetop = p.y;
             NSLog(@"2nosetop%d",nosetop);
        }
        if (nosetop - nose_top > 60 ) {
            nosetop = nose_top;
            nose_top = p.y;
        }
    }
}
//- (void)image:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo
//{
//    NSLog(@"image = %@, error = %@, contextInfo = %@", image, error, contextInfo);
//}
#pragma mark --- 拍照
-(void)didClickTakePhoto:(BOOL)isSound
{
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        AVCaptureConnection *myVideoConnection = nil;
        //从 AVCaptureStillImageOutput 中取得正确类型的 AVCaptureConnection
        for (AVCaptureConnection *connection in myStillImageOutput.connections) {
            for (AVCaptureInputPort *port in [connection inputPorts]) {
                if ([[port mediaType] isEqual:AVMediaTypeVideo]) {
                    myVideoConnection = connection;
                    break;
                }
            }
        }
        if (!isSound) {
             static SystemSoundID soundID = 0; if (soundID == 0) { NSString *path = [[NSBundle mainBundle] pathForResource:@"photoShutter2" ofType:@"caf"]; NSURL *filePath = [NSURL fileURLWithPath:path isDirectory:NO]; AudioServicesCreateSystemSoundID((__bridge CFURLRef)filePath, &soundID); } AudioServicesPlaySystemSound(soundID);
        }
        //撷取影像（包含拍照音效）
        [myStillImageOutput captureStillImageAsynchronouslyFromConnection:myVideoConnection completionHandler:^(CMSampleBufferRef imageDataSampleBuffer, NSError *error) {
            //完成撷取时的处理程序(Block)
            if (imageDataSampleBuffer) {
                NSData *imageData = [AVCaptureStillImageOutput jpegStillImageNSDataRepresentation:imageDataSampleBuffer];
                //取得的静态影像
                UIImage *myImage = [[UIImage alloc] initWithData:imageData];
                [self.arrImage addObject:myImage];
             [self doUploadPhoto:self.arrImage.lastObject];
                if (isSound) {
                dispatch_async(dispatch_get_main_queue(), ^{
                         self.textLabel.text = [NSMutableString stringWithFormat:@"已采集%lu张图像数据",(unsigned long)self.arrImage.count];
                        [self delateNumber];
                    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_global_queue(0, 0), ^{
                        [self.previewLayer.session stopRunning];
                        [self.ImageArr enumerateObjectsUsingBlock:^(NSNumber * obj, NSUInteger idx, BOOL * _Nonnull stop) {
                            if ([obj integerValue] == 0) {
                                *stop = YES;
                                [SVProgressHUD showSuccessWithStatus:@"检测失败"];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                                    [SVProgressHUD dismiss];
                                });
                            }else if(idx == self.ImageArr.count -1){
                                [SVProgressHUD showSuccessWithStatus:@"检测 成功"];
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                                    [SVProgressHUD dismiss];
                                });
                             }
                          }];
                       });
                    });
                }
            }
        }];
    });
    
    NSLog(@"self.arrImage%@",self.arrImage);
    
    
   
//             UIImageWriteToSavedPhotosAlbum(myImage, self, @selector(image:didFinishSavingWithError:contextInfo:), (__bridge void *)self);
//            - (void)loadImageFinished:(UIImage *)image
//            {
//                [[PHPhotoLibrary sharedPhotoLibrary] performChanges:^{
//
//                    /写入图片到相册
//                    PHAssetChangeRequest *req = [PHAssetChangeRequest creationRequestForAssetFromImage:image];
//
//
//                } completionHandler:^(BOOL success, NSError * _Nullable error) {
//
//                    NSLog(@"success = %d, error = %@", success, error);
//
//                }];
//            }
//            imageView.backgroundColor = [UIColor lightGrayColor];
//            imageView.image = myImage;
//            imageView.frame = CGRectMake(0, 10, ScreenWidth, ScreenWidth*myImage.size.height/myImage.size.width);
//            [self.view addSubview:backView];
            //停止摄像
    
}

- (void)doUploadPhoto:(UIImage *)image {
    NSLog(@"!!!!!!!image%@",image);
    if (image == nil) return;
    // 1.创建一个管理者
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        AFJSONRequestSerializer *rqSerializer = [AFJSONRequestSerializer serializerWithWritingOptions:0];//NSJSONWritingPrettyPrinted
        rqSerializer.stringEncoding = NSUTF8StringEncoding;
        AFJSONResponseSerializer *rsSerializer = [AFJSONResponseSerializer serializer];
        rsSerializer.stringEncoding = NSUTF8StringEncoding;
        AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
        manager.responseSerializer = rsSerializer;
        manager.requestSerializer = rqSerializer;
//        [manager.requestSerializer  setValue:@"no-cache" forHTTPHeaderField:@"Cache-Control"];
//        [manager.requestSerializer  setValue:@"text/plain" forHTTPHeaderField:@"content-type"];
//        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/json",@"text/html", @"text/javascript", @"text/plain",@"image/jpeg",@"application/zip",@"application/pdf",@"audio/mpeg",@"application/x-shockwave-flash",@"application/force-download",@"application/octet-stream",@"application/download",@"text/x-json",@"application/octet-stream",@"application/x-www-form-urlencoded",nil];
        NSMutableDictionary *params = [NSMutableDictionary dictionary];
      
        // 2.发送一个请求
        NSData *fileData = UIImageJPEGRepresentation( image, 0.5);
        [manager POST:@"http://192.168.1.68/ctid/iosCtid" parameters:params constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
            [formData appendPartWithFileData:fileData name:@"file" fileName:@"face.jpg" mimeType:@"image/jpeg"];
        } progress:^(NSProgress * _Nonnull uploadProgress) {
            if ( uploadProgress.completedUnitCount != fileData.length) {
                dispatch_async(dispatch_get_main_queue(), ^{
//                    [SVProgressHUD showSuccessWithStatus:@"正在上传中"];
                });
            }else{
                dispatch_async(dispatch_get_main_queue(), ^{
                    [SVProgressHUD dismiss];
                });
            }
        } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            NSLog(@"上传成功%@",responseObject);
            [self.ImageArr addObject:[NSNumber numberWithBool:YES]];
            
//            if ([responseObject isKindOfClass:[NSData class]]) {
//                NSDictionary *responseData = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
//                [self doUploadPhotorespondata:responseData  image:image];
//            }else{
//                [self doUploadPhotorespondata:responseObject  image:image];
//            }
            
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            NSLog(@"上传失败%@",error);
            [SVProgressHUD showSuccessWithStatus:@"上传失败"];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [SVProgressHUD dismiss];
            });
            
        }];

    });
}
-(void)doUploadPhotorespondata:(NSDictionary *)responseObject  image:(UIImage *)image{
    
}




//#pragma mark --- 重拍按钮点击事件
//-(void)didClickPhotoAgain
//{
//    //清数据
//    [self delateNumber];
//    //开始摄像
//    [self.previewLayer.session startRunning];
//    self.textLabel.text = @"请调整位置...";
//    [backView removeFromSuperview];
//    isJudgeMouth = NO;
//    isShakeHead = NO;
//}
//
//#pragma mark --- 上传图片按钮点击事件
//-(void)didClickUpPhoto
//{
////    UIAlertView *alt = [[UIAlertView alloc]initWithTitle:@"提示" message:@"验证完成" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
////    [alt show];
//    //上传照片失败
////    [self.faceDelegate sendFaceImageError];
//    //上传照片成功
//    [self.faceDelegate sendFaceImage:imageView.image];
//    [self.navigationController popViewControllerAnimated:YES];
//}
//#pragma mark - 点击『验证完成』AlertView
//-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
//{
//    if (imageView.image) {
//    //上传照片成功
//        [self.faceDelegate sendFaceImage:imageView.image];
//    //上传照片失败
//    //    [self.faceDelegate sendFaceImageError];
//        [self.navigationController popViewControllerAnimated:YES];
//    }
//}

#pragma mark --- 清掉对应的数
-(void)delateNumber
{
    number = 0;
    mouthWidthF = 0;
    mouthHeightF = 0;
    mouthWidth = 0;
    mouthHeight = 0;
    smallNumber = 0;
    bigNumber = 0;
    nosetop = 0;
    nose_top = 0;
    nosebottom = 0;
    nose_bottom =0;
    foraround = 0;
    left_eye_left = 0;
    right_eye_right = 0;
    imgView.animationImages = nil;
    imgView.image = [UIImage imageNamed:@"shakeHead0"];
}
-(UIButton *)buttonWithTitle:(NSString *)title frame:(CGRect)frame action:(SEL)action AddView:(id)view
{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    button.frame = frame;
    button.backgroundColor = [UIColor lightGrayColor];
    [button setTitle:title forState:UIControlStateNormal];
    [button addTarget:self action:action forControlEvents:UIControlEventTouchDown];
    [view addSubview:button];
    return button;
}

#pragma mark --- UIImageView显示gif动画
- (void)tomAnimationWithName:(NSString *)name count:(NSInteger)count
{
    // 如果正在动画，直接退出
    if ([imgView isAnimating]) return;
    // 动画图片的数组
    NSMutableArray *arrayM = [NSMutableArray array];
    // 添加动画播放的图片
    for (int i = 0; i < count; i++) {
        // 图像名称
        NSString *imageName = [NSString stringWithFormat:@"%@%d.png", name, i];
        // UIImage *image = [UIImage imageNamed:imageName];
        // ContentsOfFile需要全路径
        NSString *path = [[NSBundle mainBundle] pathForResource:imageName ofType:nil];
        UIImage *image = [UIImage imageWithContentsOfFile:path];
        [arrayM addObject:image];
    }
    // 设置动画数组
    imgView.animationImages = arrayM;
    // 重复1次
    imgView.animationRepeatCount = 100;
    // 动画时长
    imgView.animationDuration = imgView.animationImages.count * 0.75;
    // 开始动画
    [imgView startAnimating];
}

-(void)dealloc
{
    self.captureManager=nil;
    self.viewCanvas=nil;
    [self.previewView removeGestureRecognizer:self.tapGesture];
    self.tapGesture=nil;
}

@end
