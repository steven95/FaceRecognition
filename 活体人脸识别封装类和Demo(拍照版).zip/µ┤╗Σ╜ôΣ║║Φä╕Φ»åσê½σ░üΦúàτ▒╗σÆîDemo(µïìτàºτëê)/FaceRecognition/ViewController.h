//
//  ViewController.h
//  FaceRecognition
//
//  Created by 聚财通 on 16/3/1.
//  Copyright © 2016年 付正. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

-(void)pushToFaceStreamDetectorVC;

@end

