//
//  main.m
//  FaceRecognition
//
//  Created by 聚财通 on 16/3/1.
//  Copyright © 2016年 付正. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
